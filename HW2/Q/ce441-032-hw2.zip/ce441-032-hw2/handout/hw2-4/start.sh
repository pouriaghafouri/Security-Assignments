#!/bin/bash

python app1.py &

python app2.py &

node app3.js &

wait

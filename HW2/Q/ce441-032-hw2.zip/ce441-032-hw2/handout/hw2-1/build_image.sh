docker build -t ce441-proj2-image .
